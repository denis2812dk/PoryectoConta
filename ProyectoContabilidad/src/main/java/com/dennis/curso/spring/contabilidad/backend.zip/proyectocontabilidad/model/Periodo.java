package com.dennis.curso.spring.contabilidad.proyectocontabilidad.model;

public class Periodo {
    
}
