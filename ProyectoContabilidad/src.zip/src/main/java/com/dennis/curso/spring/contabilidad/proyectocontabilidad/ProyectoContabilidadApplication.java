package com.dennis.curso.spring.contabilidad.proyectocontabilidad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoContabilidadApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProyectoContabilidadApplication.class, args);
    }

}
