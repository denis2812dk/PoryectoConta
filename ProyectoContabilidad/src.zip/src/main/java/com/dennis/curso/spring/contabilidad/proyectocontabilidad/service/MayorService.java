package com.dennis.curso.spring.contabilidad.proyectocontabilidad.service;

import java.util.Map;

public interface MayorService {

    Map<String, Object> generarMayor();
}
