package com.dennis.curso.spring.contabilidad.proyectocontabilidad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoContabilidadApplicationTests {

    @Test
    void contextLoads() {
    }

}
